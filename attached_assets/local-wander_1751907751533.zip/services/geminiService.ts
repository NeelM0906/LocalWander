
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Itinerary, Stop, GroundingChunk } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY_MISSING");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// A curated list of high-quality, generic stock images to cycle through.
const STOCK_IMAGE_URLS = [
  'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=1470&auto=format&fit=crop', // Restaurant interior
  'https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=1637&auto=format&fit=crop', // Coffee latte art
  'https://images.unsplash.com/photo-1472851294608-062f824d29cc?q=80&w=1470&auto=format&fit=crop', // Boutique shop
  'https://images.unsplash.com/photo-1521791136064-7986c2920216?q=80&w=1469&auto=format&fit=crop', // Modern museum
  'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=1544&auto=format&fit=crop', // Cityscape
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=1471&auto=format&fit=crop', // Forest path
  'https://images.unsplash.com/photo-1550399105-c4db5fb85c18?q=80&w=1471&auto=format&fit=crop', // Bookstore
  'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=1374&auto=format&fit=crop', // Plated food
  'https://images.unsplash.com/photo-1533109721025-d1ae7de64092?q=80&w=1374&auto=format&fit=crop', // Interesting architecture
  'https://images.unsplash.com/photo-1506126613408-4e64f3835bde?q=80&w=1470&auto=format&fit=crop', // Park bench
];


// Local types for parsing the raw JSON response from the text model
interface RawStop {
  name: string;
  category: string;
  walking_time_minutes: number;
  description?: string;
  // image_url is removed as we will be providing our own
}
interface RawItinerary {
  title: string;
  description: string;
  duration_minutes: number;
  stops: RawStop[];
}
interface RawApiResponse {
    itineraries: RawItinerary[];
}


const generateTextPrompt = (location: string): string => {
  return `
You are an expert local guide named "Local Wander". Your goal is to create 3 to 5 distinct, hyper-local itineraries for a "Spontaneous Explorer" based on the provided location: "${location}".

**Constraints & Rules:**
1.  **Hyper-Local:** All stops must be within a short, walkable radius (approx. 0.25-1 mile / 0.4-1.6 km) of each other.
2.  **Duration:** Each complete itinerary should last between 1.5 hours (90 minutes) and 4 hours (240 minutes), including walking time.
3.  **Structure:** Each itinerary must have a catchy title, an energetic single-sentence description, a total duration in minutes, and a list of 2 to 4 stops.
4.  **Stops:** For each stop, provide its name, a simple category (e.g., "Park", "Cafe", "Museum", "Restaurant", "Art Gallery", "Bookstore"), the estimated walking time in minutes from the *previous* stop, and a brief, one-sentence description explaining what makes it interesting.
5.  **Logical Flow:** Arrange stops logically. For example, food-related stops should appear around meal times.
6.  **JSON Output ONLY:** Your entire response MUST be a single, valid JSON object. Do not include any text, pleasantries, or markdown formatting like \`\`\`json before or after the JSON object.
7.  **VALID JSON:** The generated JSON must be syntactically correct. Pay special attention to not including trailing commas in arrays or objects.
8.  **START WITH JSON:** Your response must begin immediately with the opening curly brace '{' of the JSON object.
9.  **ESCAPE QUOTES:** Ensure that any double quotes inside string values (like in a description) are properly escaped with a backslash (e.g., "a \\"quoted\\" word").
10. **NO COMMENTS:** Do not include comments (like // or /* */) in the JSON output.

**JSON Schema:**
{
  "itineraries": [
    {
      "title": "string",
      "description": "string",
      "duration_minutes": "number",
      "stops": [
        {
          "name": "string",
          "category": "string",
          "walking_time_minutes": "number",
          "description": "string"
        }
      ]
    }
  ]
}

Now, generate the itineraries for "${location}".
`;
};

export const getItineraries = async (location: string): Promise<{itineraries: Itinerary[], sources: GroundingChunk[]}> => {
  try {
    // === 1. Generate Itinerary TEXT Data ===
    const textPrompt = generateTextPrompt(location);
    const textResponse: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: textPrompt,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    const sources = textResponse.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] || [];
    
    let responseText = textResponse.text.trim();
    
    // The model can sometimes return conversational text or markdown. This logic extracts the clean JSON string.
    const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
    const match = responseText.match(fenceRegex);
    if (match && match[1]) {
        responseText = match[1].trim();
    } else {
        // If no markdown fence is found, find the first '{' and last '}' to isolate the JSON object.
        const firstBrace = responseText.indexOf('{');
        const lastBrace = responseText.lastIndexOf('}');
        if (firstBrace !== -1 && lastBrace > firstBrace) {
            responseText = responseText.substring(firstBrace, lastBrace + 1);
        }
    }

    // This regex removes comments from the JSON string, which are invalid.
    responseText = responseText.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
    
    // This regex removes trailing commas from arrays and objects to prevent parsing errors.
    responseText = responseText.replace(/,\s*([}\]])/g, '$1');

    const parsedData: RawApiResponse = JSON.parse(responseText);
    
    if (!parsedData.itineraries || !Array.isArray(parsedData.itineraries)) {
        throw new Error("Invalid data format received from API.");
    }

    // === 2. Process itineraries, adding unique IDs and assigning images from our stock list ===
    let imageIndex = 0;
    const finalItineraries: Itinerary[] = parsedData.itineraries.map((itinerary, i) => {
        const stopsWithGuaranteedImages: Stop[] = itinerary.stops.map((stop, j) => {
            const imageUrl = STOCK_IMAGE_URLS[imageIndex % STOCK_IMAGE_URLS.length];
            imageIndex++; // Increment for the next stop to cycle through images
            
            return {
                ...stop,
                id: `stop-${i}-${j}-${Date.now()}-${Math.random()}`,
                image_url: imageUrl,
            };
        });

        return {
            ...itinerary,
            id: `itinerary-${i}-${Date.now()}`,
            stops: stopsWithGuaranteedImages,
        };
    });
    
    return { itineraries: finalItineraries, sources };

  } catch (error) {
    console.error("Error fetching or parsing itineraries:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid') || error.message.includes('API_KEY_INVALID')) {
          throw new Error('INVALID_API_KEY');
        }
        if (error.message.includes("429")) { // Quota errors
          throw new Error("The request was blocked due to rate limiting. Please try again later.");
        }
    }
    // Check for JSON parsing error and provide a more specific message.
    if (error instanceof SyntaxError) {
        throw new Error("Failed to parse the itinerary data from the AI model. The format was invalid.");
    }
    throw new Error("Failed to generate itineraries from the AI model.");
  }
};
